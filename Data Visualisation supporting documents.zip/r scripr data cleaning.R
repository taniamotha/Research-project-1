dataset <- read.csv("C:/Users/User/Desktop/Data VIS/countries.csv")

class(dataset)
head(dataset)
str(dataset)

#indentifying the columns of the dataset
names(dataset)

#cleaning and preperation of the dataset
dataset <- na.omit(dataset)

#Remove Duplicated Rows
dataset <- dataset[!duplicated(dataset), ]

#Remove Unwanted Columns
columns_to_keep <- c("Country", "Region", "Population", "HDI", "GDP.per.Capita", 
                     "Cropland.Footprint", "Grazing.Footprint", "Forest.Footprint", 
                     "Carbon.Footprint", "Fish.Footprint", "Total.Ecological.Footprint", 
                     "Total.Biocapacity", "Biocapacity.Deficit.or.Reserve", "Earths.Required", 
                     "Countries.Required")
dataset <- dataset[, columns_to_keep]

# Convert GDP per Capita to numeric by removing $ symbol and commas
dataset$GDP.per.Capita <- as.numeric(gsub("[\\$,]", "", dataset$GDP.per.Capita))

# Save the Cleaned Data
write.csv(dataset, "C:/Users/User/Desktop/Data VIS/cleaned_countries.csv", row.names = FALSE)

#View the first few rows of the cleaned data
head(dataset)
